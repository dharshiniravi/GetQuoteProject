<!-- Use preprocessors via the lang attribute! e.g. <template lang="pug"> -->
<template>
  <div id="app">
    <!---implementation of search bar--->
    <div id="search-box">
      <input id="text-box" type="text" v-model="get" placeholder="Symbol Lookup">
      <button @click="getNewQuote()">Get New Quote</button>
    </div>
    <!--showing error for an invalid symbol--->
    <div v-if="error === true" style="color:#f73a25">Please enter a valid Symbol</div>
    <!--displaying fields stockname and symbol--->
    <div class="header">
      <h5 style="display:inline">{{stockname}}</h5>
        <h5 style="display:inline">({{symbol}})</h5>
    </div> 
    <!--displaying change and changepercent values-->
    <div class="change-values">      
      <h1 style="display:inline">{{lastprice}}</h1>
      <section style="display:inline" id="values">
        <p style="display:inline; color:#0cab11" v-if="change>0">+{{change}}</p>
        <p style="display:inline; color:#0cab11" v-if="changepercent>0">(+{{changepercent}}%)</p>
        <p style="display:inline; color:#f73a25" v-if="change<0">{{change}}</p>
        <p style="display:inline; color:#f73a25" v-if="changepercent<0">({{changepercent}}%)</p>
      </section>
      <p id="timestamp">As of {{timestamp}}</p>
    </div> 
   <!---using grid to display the table values-->
    <div id="table" class = "container">
      <div style="border-top:1px solid #cdd4cf" id="table-row" class="row">
        <div id="row-name" class="col-sm-6">Range</div>        
        <div id="col-data" class="col-sm-6">{{low}} - {{high}}</div>        
      </div>
      <div id="table-row" class="row">
        <div id="row-name" class="col-sm-6">Open</div>        
        <div id="col-data" class="col-sm-6">{{open}}</div>        
      </div>
      <div id="table-row" class="row">
        <div id="row-name" class="col-sm-6">Volume</div>        
        <div id="col-data" class="col-sm-6">{{volume}}</div>        
      </div>      
      <div id="table-row" class="row">
        <div id="row-name" class="col-sm-6">Maket Cap</div>       
        <div id="col-data" class="col-sm-6">{{marketcap}}</div> 
      </div>
    </div>
  </div>
</template>

<script>
  const dataList = {
  AAPL:
  {
    Change: -1.51999999999998,
    ChangePercent: -0.977806368607258,
    ChangePercentYTD: 32.9045069936108,
    ChangeYTD: 115.82,
    High: 154.45,
    LastPrice: 153.93,
    Low: 153.46,
    MSDate: 42891,
    MarketCap: 802566391200,
    Name: "Apple Inc",
    Open: 154.34,
    Status: "SUCCESS",
    Symbol: "AAPL",
    Timestamp: "08:10:15 PM ET",
    Volume: 25331662
  },
  AME:
  {
    Change: -0.269999999999996,
    ChangePercent: -0.436893203883489,
    ChangePercentYTD: 26.6049382716049,
    ChangeYTD: 48.6,
    High: 61.76,
    LastPrice: 61.53,
    Low: 61.25,
    MSDate: 42892.6622569544,
    MarketCap: 14158545240,
    Name: "Ametek Inc",
    Open: 61.38,
    Status: "SUCCESS",
    Symbol: "AME",
    Timestamp: "15:53:39 PM ET",
    Volume: 601580
  },
  BIG:
  {
    Change: -1.36,
    ChangePercent: -2.73972602739726,
    ChangePercentYTD: -3.84385580561641,
    ChangeYTD: 50.21,
    High: 49.17,
    LastPrice: 48.28,
    Low: 47.99,
    MSDate: 42892.6620949074,
    MarketCap: 2162268080,
    Name: "Big Lots Inc",
    Open: 49.17,
    Status: "SUCCESS",
    Symbol: "BIG",
    Timestamp: "15:53:25 PM ET",
    Volume: 1253948
  },
  BRKA:
  {
    Change: -550,
    ChangePercent: -0.22,
    ChangePercentYTD: 2.18293387295644,
    ChangeYTD: 244121,
    High: 250012,
    LastPrice: 249450,
    Low: 248650,
    MSDate: 42892.6520023148,
    MarketCap: 191827050000,
    Name: "Berkshire Hathaway Inc",
    Open: 249200.01,
    Status: "SUCCESS",
    Symbol: "BRK.A",
    Timestamp: "15:38:53 PM ET",
    Volume: 297
  },
  CVS:
  {
    Change: -0.984999999999999,
    ChangePercent: -1.25015864957482,
    ChangePercentYTD: -1.40032948929159,
    ChangeYTD: 78.91,
    High: 78.52,
    LastPrice: 77.805,
    Low: 77.64,
    MSDate: 42892.6627199094,
    MarketCap: 79267344975,
    Name: "CVS Health Corp",
    Open: 78.41,
    Status: "SUCCESS",
    Symbol: "CVS",
    Timestamp: "15:54:19 PM ET",
    Volume: 3812490
  },
  F:
  {
    Change: -0.109999999999999,
    ChangePercent: -0.977777777777773,
    ChangePercentYTD: -8.16158285243199,
    ChangeYTD: 12.13,
    High: 11.2,
    LastPrice: 11.14,
    Low: 11.05,
    MSDate: 42892.6552777808,
    MarketCap: 43570032760,
    Name: "Ford Motor Co",
    Open: 11.19,
    Status: "SUCCESS",
    Symbol: "F",
    Timestamp: "15:43:36 PM ET",
    Volume: 40054809
  },
  INFO:
  {
    Change: -0.260000000000005,
    ChangePercent: -0.552486187845315,
    ChangePercentYTD: 32.1660547867834,
    ChangeYTD: 35.41,
    High: 47.2,
    LastPrice: 46.8,
    Low: 46.71,
    MSDate: 42891,
    MarketCap: 19041750000,
    Name: "IHS Markit Ltd",
    Open: 47.03,
    Status: "SUCCESS",
    Symbol: "INFO",
    Timestamp: "00:00:00 PM ET",
    Volume: 4082775
  },
  JWN:
  {
    Change: -1.565,
    ChangePercent: -3.75750300120047,
    ChangePercentYTD: -16.367619445024,
    ChangeYTD: 47.93,
    High: 41.66,
    LastPrice: 40.085,
    Low: 39.715,
    MSDate: 42892.6625810225,
    MarketCap: 6656194420,
    Name: "Nordstrom Inc",
    Open: 41.51,
    Status: "SUCCESS",
    Symbol: "JWN",
    Timestamp: "15:54:07 PM ET",
    Volume: 4133041
  },
  MET:
  {
    Change: -0.705000000000005,
    ChangePercent: -1.37883825542735,
    ChangePercentYTD: -6.42976433475599,
    ChangeYTD: 53.89,
    High: 50.83,
    LastPrice: 50.425,
    Low: 50.13,
    MSDate: 42892.6630324074,
    MarketCap: 54253921525,
    Name: "Metlife Inc",
    Open: 50.7,
    Status: "SUCCESS",
    Symbol: "MET",
    Timestamp: "15:54:46 PM ET",
    Volume: 3751545
  },
  MS:
  {
    Change: 0.104999999999997,
    ChangePercent: 0.244812310561895,
    ChangePercentYTD: 1.76331360946745,
    ChangeYTD: 42.25,
    High: 43.07,
    LastPrice: 42.995,
    Low: 42.21,
    MSDate: 42892.6628587963,
    MarketCap: 79531377090,
    Name: "Morgan Stanley",
    Open: 42.44,
    Status: "SUCCESS",
    Symbol: "MS",
    Timestamp: "15:54:31 PM ET",
    Volume: 5471583
  },
  MSFT:
  {
    Change: 0.519999999999996,
    ChangePercent: 0.724637681159415,
    ChangePercentYTD: 16.3179916317992,
    ChangeYTD: 62.14,
    High: 72.89,
    LastPrice: 72.28,
    Low: 71.81,
    MSDate: 42891,
    MarketCap: 558038824200,
    Name: "Microsoft Corp",
    Open: 71.97,
    Status: "SUCCESS",
    Symbol: "MSFT",
    Timestamp: "22:56:05 PM ET",
    Volume: 33316760
  },
  PLT:
  {
    Change: -0.18,
    ChangePercent: -0.323682790864952,
    ChangePercentYTD: 1.22352081811542,
    ChangeYTD: 54.76,
    High: 55.94,
    LastPrice: 55.43,
    Low: 55.02,
    MSDate: 42892.6617824084,
    MarketCap: 1853412910,
    Name: "Plantronics Inc",
    Open: 55.44,
    Status: "SUCCESS",
    Symbol: "PLT",
    Timestamp: "15:52:58 PM ET",
    Volume: 94192
  },
  RND:
  {
    Change: 5.336558185297221,
    ChangePercent: 10.628976347199362,
    ChangePercentYTD: -19.80145250258202,
    ChangeYTD: 44.50321345826342,
    High: 20.581252187035098,
    LastPrice: 220.0708646245192,
    Low: 4.432608704792276,
    MarketCap: 1943062764039205.5,
    Name: "Random Company Date Example",
    Open: 445.63898384179413,
    Status: "SUCCESS",
    Symbol: "RND",
    Timestamp: "12:50:47 PM ET",
    Volume: 9688624232270186
  },
  TWX:
  {
    Change: -0.240000000000009,
    ChangePercent: -0.240722166499508,
    ChangePercentYTD: 3.03532580544908,
    ChangeYTD: 96.53,
    High: 99.82,
    LastPrice: 99.46,
    Low: 99.44,
    MSDate: 42892.6622916667,
    MarketCap: 77135009480,
    Name: "Time Warner Inc",
    Open: 99.65,
    Status: "SUCCESS",
    Symbol: "TWX",
    Timestamp: "15:53:42 PM ET",
    Volume: 2953535
  }
}
export default {     
  mounted() {
    var self = this;
    self.symbol = "MSFT"; //loading symbol MSFT at the initial stage
    self.getNewQuote();
  },
  data() {
    return {
      error: false,
      sign: '+',
      signPercent: '+',
      get: '',
      timestamp: '',
      stockname: 'stockname',
      symbol: 'symbol',
      lastprice: 0,
      low: 0,
      high: 0,
      change: 0,
      changepercent: 0,
      open: 0,
      marketcap: 'marketcap',
      volume: 0
    };
  },
  methods: {
    getNewQuote() {
      var self = this;
      self.error = false; //reseting the error value
      if(self.get === ""){
        self.symbol = "MSFT"; //load MSFT table even if no value is entered
      } else if(dataList.hasOwnProperty(self.get.toUpperCase()) !== true){
        self.error = true; //set error as true for any invalid symbol
        self.symbol = "MSFT"; //reset the table for any wrong input
      } else{        
        self.symbol = self.get.toUpperCase();
      }
      //assigning the values from the dataList
      self.high = dataList[self.symbol].High;
      self.low = dataList[self.symbol].Low;
      self.marketcap = dataList[self.symbol].MarketCap;
      self.lastprice = dataList[self.symbol].LastPrice;
      self.change = dataList[self.symbol].Change;
      self.changepercent = dataList[self.symbol].ChangePercent;
      self.stockname = dataList[self.symbol].Name;
      self.open = dataList[self.symbol].Open;
      self.volume = dataList[self.symbol].Volume;
      self.timestamp = dataList[self.symbol].Timestamp;
      self.change = Math.round(self.change * 100) / 100;
      self.changepercent = Math.round(self.change * 100) / 100;
      self.stockname = self.stockname.toUpperCase();
      //rounding off the values
      self.volume = (self.volume/1000000).toFixed(1)+"M";
      self.marketcap = (self.marketcap/1000000000).toFixed(1)+"B";
      self.high = self.high.toFixed(2);
      self.low = self.low.toFixed(2);
      self.lastprice = self.lastprice.toFixed(2);
      self.open = self.open.toFixed(2);
      self.get = "";
    }
  }
};
</script>

<!-- Use preprocessors via the lang attribute! e.g. <style lang="scss"> -->
<style>
#app {
  margin-left: 20px;
  margin-top:20px;
  font-size: 15px;
  font-family: Arial, Helvetica, sans-serif;
 }
  #search-box {
    padding-bottom: 20px;
  }
  #text-box {
    border-radius: 5px;
  }
  #row-name {
    color: #989c99;
    font-size: 15px;
  }
  #col-data{
    font-weight: bold;
  }
  #timestamp {
    font-size: 12px;
    font-weight: bold;
    color: #989c99;
  }
  #table {
    float:left;
    border-width: 1px;
  }
  #table-row{
    border-bottom: 1px solid #cdd4cf;
    padding: 10px;
  }
 .header {
   border-top: 1px solid #000;
   font-weight: bold;
    padding-top: 10px;
    color: #989c99;
 }
 .change-values {
   padding-top: 10px;
  }
  #values{
    font-size: 20px;
    padding-left: 10px;
  }
 button {
   cursor: pointer;
  font-size: 14px;
  color: #444344;
  background-color: #f0eeeb;
  border: solid 1px;
  border-radius: 5px;
  padding: 3px;
 }
</style>